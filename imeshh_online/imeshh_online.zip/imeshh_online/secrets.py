def get_secrets():
    return {
        'WC_CONSUMER_KEY': 'ck_91dc45c88ee91a735019d397d5ac67b872e0c334',
        'WC_CONSUMER_SECRET': 'cs_ed0328b5586de9916ac1dcf7ebd524199b3fb6ef',
    }